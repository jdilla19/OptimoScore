import { Link } from "react-router-dom"

const NotFound = () => {
  return (
    <div className="flex flex-col gap-[50px] items-center justify-center">
    
    <h1>404 Page Not Found</h1>
    <Link to="/" className="text-blue-700 border-b-1 ">Back to Home page</Link>
    </div>
    
  )
}

export default NotFound