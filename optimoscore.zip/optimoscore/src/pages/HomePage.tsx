import AddBanner from "../components/UI/SectionComponents/AddBanner";
import MatchFilter from "../components/UI/SectionComponents/MatchFilter";
import MatchContainer from "../components/UI/SectionComponents/MatchContainer";
import SportListButtons from "../components/UI/SectionComponents/SportListButtons";
import star from "../assets/icons/Star.svg";
import football from "../assets/icons/Football2.svg";
import basketball from "../assets/icons/Basketball.svg";
import hockey from "../assets/icons/Hockey.svg";
import rugby from "../assets/icons/Rugby.svg";
import handball from "../assets/icons/Handball.svg";

const HomePage = () => {
  const sportsItems = [
    { iconImg: star, text: "Favourites" },
    { iconImg: football, text: "Football" },
    { iconImg: basketball, text: "Basketball" },
    { iconImg: hockey, text: "Hockey" },
    { iconImg: handball, text: "Handball" },
    { iconImg: rugby, text: "Rugby" },
    { iconImg: rugby, text: "Rugby" },
    
  ];

  return (
    <>
      <div className="max-w-[1280px] mx-auto ">
        <SportListButtons items={sportsItems} />
        <AddBanner />

        <div className="bg-white py-[12px] mt-[20px]">
          <MatchFilter />
        </div>

        <MatchContainer />
      </div>
    </>
  );
};

export default HomePage;
