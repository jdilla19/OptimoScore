import { ReactSVG } from "react-svg";
import pin from "../../assets/icons/Pin.svg";

export interface IProps {
  imgUrl: string;
  title: string;
  subtitle?: string;
  iconUrl?: string;
}

const PinnedLeagueCard = ({
  imgUrl,
  title,
  subtitle,
}: IProps) => {
  return (
    <div className="group flex items-center justify-between space-x-3 p-2 hover:bg-gray-100 ">
      <div className="flex items-center gap-[5px]">
        <img src={imgUrl} alt={title} className="w-6 h-6" />
        <div className="flex-row items-center gap-[1px]">
          <h3 className="font-semibold text-gray-900 text-sm">
            {title}
          </h3>
          {subtitle && <p className="text-gray-500 text-[10px]">{subtitle}</p>}
        </div>
      </div>

      <ReactSVG
        src={pin}
        className={"hidden group-hover:flex fill-[#7F3FFC] stroke-[#7F3FFC]"}
      />
    </div>
  );
};

export default PinnedLeagueCard;
