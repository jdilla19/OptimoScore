
export interface IProps {
    imgUrl: string;
    subtitle: string;
    iconUrl?: string;
  }
  
const CountriesCard = ({
  imgUrl,
  subtitle,
}:IProps) => {
  
  return (
    <div className=" mx-auto mt-[5px] flex flex-row items-center justify-between space-x-3 p-2 hover:bg-gray-100">
      <div className="flex gap-[5px] items-center">
      <img src={imgUrl} alt={subtitle} className="w-6 h-6" />
      <h3 className="font-semibold text-gray-900 text-sm">
            {subtitle}
          </h3>
      </div>
    </div>
  );
}

export default CountriesCard