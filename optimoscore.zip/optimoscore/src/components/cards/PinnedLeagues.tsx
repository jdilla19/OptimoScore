import PinnedLeagueCard from "./PinnedLeagueCard";
import leaguesLogo from "../../assets/icons/leagues.svg";

export const leagues = [
  {
    id: 1,
    imgUrl: leaguesLogo,
    title: "Bundesliga",
    subtitle: "Germany",
  },
  {
    id: 2,
    imgUrl: leaguesLogo,
    title: "Seria A",
    subtitle: "Italy",
  },
  {
    id: 3,
    imgUrl: leaguesLogo,
    title: "Premier League",
    subtitle: "England",
  },
  {
    id: 4,
    imgUrl: leaguesLogo,
    title: "Ligue 1",
    subtitle: "France",
  },
  {
    id: 5,
    imgUrl: leaguesLogo,
    title: "Eredevise",
    subtitle: "Netherlands",
  },
  {
    id: 6,
    imgUrl: leaguesLogo,
    title: "La Liga",
    subtitle: "Spain",
  },
];

const PinnedLeagues = () => {
  return (
    <div className="mx-auto mt-[24px] w-[248px]">
      <h2
        className={`font-bold text-lg mb-3 border-b pb-2 border-b-[#23262E1A] `}
      >
        Pinned Leagues
      </h2>
      <div className="flex-row items-start">
        {leagues.map((league): any => (
          <PinnedLeagueCard
            key={league.id}
            imgUrl={league.imgUrl}
            title={league.title}
            subtitle={league.subtitle}
          />
        ))}
      </div>
    </div>
  );
};

export default PinnedLeagues;
