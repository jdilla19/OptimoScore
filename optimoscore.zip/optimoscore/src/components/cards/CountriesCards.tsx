import countryLogo from "../../assets/icons/Flag.svg";
// import PinnedLeagueCard from "./PinnedLeagueCard";
import CountriesCard from "./CountriesCard";
import search from "../../assets/icons/Search.svg";
import arrow from "../../assets/icons/Up.svg";

interface ILeague {
  imgUrl: string;
  title: string;
  id:number;
  
}

const leagues: ILeague[] = [
  {
    id:1,
    imgUrl: countryLogo,
    title: "Georgia",
  },
  {
    id:2,
    imgUrl: countryLogo,
    title: "Italy",
  },
  {
    id:3,
    imgUrl: countryLogo,
    title: "England",
  },
  {
    id:4,
    imgUrl: countryLogo,
    title: "France",
  },
  {
    id:5,
    imgUrl: countryLogo,
    title: "Netherlands",
  },
  {
    id:6,
    imgUrl: countryLogo,
    title: "Spain",
  },
  {
    id:7,
    imgUrl: countryLogo,
    title: "Albania",
  },
  {
    id:8,
    imgUrl: countryLogo,
    title: "Armenia",
  },
];

const CountriesCards = () => {
  return (
    <div className=" mx-auto mt-[20px] flex-row gap-4 w-[248px]">
      <h2 className={`font-bold text-lg border-b-[#23262E1A] my-3`}>
        Countries {`[A-Z]`}
      </h2>
      <div className="flex items-center rounded-lg px-3 w-full h-10 bg-white">
      <input
        type="text"
        placeholder="Search Country"
        className={`flex-1 bg-transparent outline-none placeholder-gray-400 text-xs  text-[#23262e66]`}
      />
      <img src={search} alt="" />
       
      </div>


      <div className="flex-row items-start">
        {leagues.map((leagues, index) => (
          <CountriesCard
            key={index}
            imgUrl={leagues.imgUrl}
            subtitle={leagues.title}
            iconUrl={arrow}
          />
        ))}
      </div>
    </div>
  );
};

export default CountriesCards;
