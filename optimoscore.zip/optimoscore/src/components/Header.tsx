import Select from "./UI/HeaderComponents/Select";
import Logo from "../assets/Logo.png";
import Button from "./UI/HeaderComponents/Button";
import Star from "../assets/icons/Star.svg";
import SearchBar from "./UI/HeaderComponents/SearchBar";
import Setting from "../assets/icons/Setting.svg";
import Platform from "../assets/icons/Platform.svg";
import ButtonUrl from "./UI/HeaderComponents/ButtonUrl";
// import burgerIcon from "../assets/icons/Burger.svg"
import Buttons from "./UI/HeaderComponents/Buttons";
import BurgerMenu from "./UI/HeaderComponents/BurgerMenu";
import SettingsModal from "./UI/modals/SettingsModal";
import { Link, useNavigate, useLocation } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const params = new URLSearchParams(location.search);

  const handleOpen = () => {
    params.set("modal", "settings");
    navigate(`${location.pathname}?${params}`);
  };

  const handleClose = () => {
    params.delete("modal");

    navigate(`${location.pathname}?${params}`);
  };

  return (
    <>
      <header className="w-full flex bg-white">
        <SettingsModal
          isOpen={params.get("modal") === "settings"}
          handleClose={handleClose}
        />
        {/* <Layout> */}
        <div className="con h-[80px] flex items-center justify-center">
          <div className=" flex items-center justify-between gap-x-4 w-full">
            <div className="flex items-center gap-x-4">
              <BurgerMenu />
              <Link to="/">
                <img
                  src={Logo}
                  alt=""
                  className="h-8 items-center !w-[120px] md:!w-[232px]"
                />
              </Link>

              <Select />
              <Button iconUrl={Star} text="Favourites" count={12} />
            </div>

            <div className="flex items-center gap-x-4">
              <SearchBar />
              <div className="gap-x-4 hidden lg:flex">
                <ButtonUrl iconUrl={Setting} onClick={handleOpen} />
                <ButtonUrl iconUrl={Platform} />
              </div>

              <Buttons text="Sign in" isActive={true} />
            </div>
          </div>
        </div>
        {/* </Layout> */}
      </header>
    </>
  );
};

export default Header;
