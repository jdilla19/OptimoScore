import PinnedLeagues from "../cards/PinnedLeagues";
import CountriesCards from "../cards/CountriesCards";

const LeftSideBar = () => {
  return (
    <div>
      <PinnedLeagues />
      <CountriesCards />
    </div>
  );
};

export default LeftSideBar;
