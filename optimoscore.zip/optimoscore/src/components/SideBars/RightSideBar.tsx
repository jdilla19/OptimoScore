import DownloadApp from "../UI/SectionComponents/DownloadApp";
import Banner from "../UI/SectionComponents/Banner";

const RightSideBar = () => {
  return (
    <div>
      <DownloadApp />
      <Banner />
    </div>
  );
};

export default RightSideBar;
