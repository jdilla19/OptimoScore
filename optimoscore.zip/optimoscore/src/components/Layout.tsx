import { Outlet } from "react-router-dom";
import Header from "./Header";
import LeftSideBar from "./SideBars/LeftSideBar";
import RightSideBar from "./SideBars/RightSideBar";
import Footer from "./Footer";

const Layout = () => {
  return (
    <div className="flex flex-col items-center">
      <Header />

      <div className="block md:flex justify-between con max-md:!px-0">
        <aside className="hidden lg:flex">
          <LeftSideBar />
        </aside>

        <main className="flex-1 md:px-6 px-0">
          <Outlet />{" "}
        </main>

        <aside className="flex">
          <RightSideBar />
        </aside>
      </div>

      <Footer />
    </div>
  );
};

export default Layout;
