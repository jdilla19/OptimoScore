import Live from "../../../assets/icons/Live.svg";
import arrow from "../../../assets/icons/Up.svg";
import calendar from "../../../assets/icons/Calendar.svg";
import Buttons from "../../UI/HeaderComponents/Buttons";
import time from "../../../assets/icons/Time.svg";
import ButtonUrl from "../HeaderComponents/ButtonUrl";
import { Segmented } from "antd";
import { useState } from "react";



// const FILTERS = [
//   { label: "All Matches", value: "ALL" },
//   { label: "Live (12)", value: "Live", icon: <img src={Live} /> },
//   { label: "Finished", value: "Finnished" },
//   { label: "Scheduled", value: "Scheduled" },
// ];

// const MatchFilter = () => {
//   const [filtered, setFiltered] = useState(FILTERS[0].value);

//   return (
//     <>
//       <div className="items-center justify-between bg-white h-[44px] rounded-md m-[20px] flex max-md:justify-center max-md:h-[90px]">
//         <div className="hidden md:flex">
//           <Segmented<string>
//             value={filtered}
//             className="MatchFilter hidden md:flex"
//             options={FILTERS}
//             onChange={(value) => {
//               setFiltered(value);
//             }}
//           />
//         </div>

//         {/* <div className="flex md:hidden items-center justify-center mx-auto">
//           <div className="flex flex-col items-center justify-center gap-[12px]">
//             <div className="flex gap-[8px] justify-center items-center">
//               <Buttons
//                 bgColor="bg-white"
//                 textColor="text-[#23262E]"
//                 text="All"
//               />
//               <Buttons
//                 bgColor="bg-white"
//                 textColor="text-[#23262E]"
//                 text="Live (12)"
//               />
//               <Buttons
//                 bgColor="bg-white"
//                 textColor="text-[#23262E]"
//                 text="Finished"
//               />
//               <Buttons
//                 bgColor="bg-white"
//                 textColor="text-[#23262E]"
//                 text="Scheduled"
//               />
//             </div>

//             <div className="flex items-center justify-between gap-[10px] ">
//               <div className="flex items-center justify-between bg-[#f7f8fa] px-[12px] py-[8px] rounded-[8px]  w-[300px] h-[40px]  ">
//                 <button>
//                   <img src={arrow} alt="prev" className="rotate-270" />
//                 </button>
//                 <span className="flex items-center text-[14px] gap-[6px]">
//                   <img src={calendar} alt="calendar" /> 01.08 THU
//                 </span>
//                 <button>
//                   <img src={arrow} alt="next" className="rotate-90" />
//                 </button>
//               </div>

//               <div className="time-button">
//                 <ButtonUrl iconUrl={time} />
//               </div>
//             </div>
//           </div>
//         </div> */}

//         <div className="flex md:hidden items-center justify-center ">
//           <div className="flex flex-col items-center justify-center gap-[12px]">
//             {/* Buttons Group */}
//             <div className="flex gap-[8px] justify-center items-center">
//               {FILTERS.map((btn) => (
//                 <Buttons
//                   key={btn.value}
//                   text={btn.label}
//                   isActive={filtered === btn.value}
//                   activeBgColor={`${
//                     btn.value === "Live"
//                       ? "bg-[red] text-white"
//                       : "bg-purple-500 text-white"
//                   }`}
//                   onClick={() => setFiltered(btn.value)}
//                 />
//               ))}
//             </div>

//             <div className="flex items-center justify-between gap-[10px]">
//               <div className="flex items-center justify-between bg-[#f7f8fa] px-[12px] py-[8px] rounded-[8px] w-full md:w-[196px] h-[40px]">
//                 <button>
//                   <img src={arrow} alt="prev" className="rotate-270" />
//                 </button>
//                 <span className="flex items-center text-[14px] gap-[6px]">
//                   <img src={calendar} alt="calendar" /> 01.08 THU
//                 </span>
//                 <button>
//                   <img src={arrow} alt="next" className="rotate-90" />
//                 </button>
//               </div>

//               <div className="time-button">
//                 <ButtonUrl iconUrl={time} />
//               </div>
//             </div>
//           </div>
//         </div>

//         <div className="items-center gap-5 px-3 py-1 rounded-[12px] justify-center w-[196px] h-full  bg-[#F7F8FA] hidden md:flex">
//             <img src={arrow} alt="" className="rotate-270" />
//           <span className="text-sm flex gap-2">
//             <img src={calendar} alt="" />
//             01.08 THU
//           </span>
//             <img src={arrow} alt="" className="rotate-90" />
//         </div>
//       </div>
//     </>
//   );
// };

const DESKTOP_FILTERS = [
  { label: "All Matches", value: "ALL" },
  { label: "Live (12)", value: "Live", icon: <img src={Live} /> },
  { label: "Finished", value: "Finnished" },
  { label: "Scheduled", value: "Scheduled" },
];

const MOBILE_FILTERS = [
  { label: "All", value: "ALL" },
  { label: "Live (12)", value: "Live", icon: <img src={Live} /> },
  { label: "Finished", value: "Finnished" },
  { label: "Scheduled", value: "Scheduled" },
];

const MatchFilter = () => {
  const [filtered, setFiltered] = useState("ALL");

  return (
    <>
      <div className="items-center justify-between bg-white h-[44px] rounded-md m-[20px] flex max-md:justify-center max-md:h-[90px]">
        <div className="hidden md:flex">
          <Segmented<string>
            value={filtered}
            className="MatchFilter hidden md:flex"
            options={DESKTOP_FILTERS}
            onChange={(value) => {
              setFiltered(value);
            }}
          />
        </div>

        <div className="flex md:hidden items-center justify-center ">
          <div className="flex flex-col items-center justify-center gap-[12px]">
            {/* Buttons Group */}
            <div className="flex gap-[8px] justify-center items-center">
              {MOBILE_FILTERS.map((btn) => (
                <Buttons
                  key={btn.value}
                  text={btn.label}
                  isActive={filtered === btn.value}
                  activeBgColor={`${
                    btn.value === "Live"
                      ? "bg-[red] text-white"
                      : "bg-purple-500 text-white"
                  }`}
                  onClick={() => setFiltered(btn.value)}
                />
              ))}
            </div>

            <div className="flex items-center justify-between gap-[10px]">
              <div className="flex items-center justify-between bg-[#f7f8fa] px-[12px] py-[8px] rounded-[8px] w-[300px]  h-[40px] max-sm:w-[250px]">
                <button>
                  <img src={arrow} alt="prev" className="rotate-270" />
                </button>
                <div className="flex gap-5">
                <img src={calendar} alt="calendar" />
                <span className="flex items-center text-[14px] gap-[6px]">
                 01.08 THU
                </span>
                </div>
               
                <button>
                  <img src={arrow} alt="next" className="rotate-90" />
                </button>
              </div>

              <div className="time-button">
                <ButtonUrl iconUrl={time} />
              </div>
            </div>
          </div>
        </div>

        <div className="items-center gap-5 px-3 py-1 rounded-[12px] justify-center w-[196px] h-full  bg-[#F7F8FA] hidden md:flex">
            <img src={arrow} alt="" className="rotate-270" />
          <span className="text-sm flex gap-2">
            <img src={calendar} alt="" />
            01.08 THU
          </span>
            <img src={arrow} alt="" className="rotate-90" />
        </div>
      </div>
    </>
  );
};


export default MatchFilter;
