import bannerPic from '../../../assets/Banner.png'

const Banner = () => {
  return (
    <div className='mt-[20px] hidden xl:flex'>
        <img src={bannerPic} alt="" />
    </div>
    
  )
}

export default Banner