import { ReactSVG } from "react-svg";


interface MatchHeaderProps {
  flagSrc: string;
  country: string;
  league: string;
  star: string;
  pin: string;
  list: string;
  arrow: string;
  id: number;
  onToggleExpand: () => void;
  isExpanded: boolean;
}

interface MatchHeaderProps {
  flagSrc: string;
  country: string;
  league: string;
  star: string;
  pin: string;
  list: string;
  arrow: string;
  id: number;
  onToggleExpand: () => void;
  isExpanded: boolean;
}

const MatchHeader: React.FC<MatchHeaderProps> = ({
  flagSrc,
  country,
  league,
  star,
  pin,
  list,
  arrow,
  onToggleExpand,
}) => {
  return (
    <>
    <div
      className="grid grid-cols-[auto_1fr_auto_auto] items-center w-full h-12 bg-[#23262E1A] px-4 py-2 gap-4 max-md:hidden"
      onClick={() => onToggleExpand()}
    >
      <div className="flex items-center gap-2 max-md">
        <img src={star} alt="Star" className="w-5 h-5 cursor-pointer" />
        <img src={flagSrc} alt="Flag" className="w-5 h-5" />
        <span className="text-[#23262E] text-sm font-medium">
          {country}: {league}
        </span>
        {/* <img src={pin} alt="Pin" className="w-5 h-5 cursor-pointer" /> */}
        <ReactSVG
        src={pin}
        className={"fill-[transparent] stroke-[black]"}
      />
      </div>

      <div className="col-span-1 grid grid-cols-[10fr_1fr] justify-end gap-6 pr-8 ">
        <span className="text-sm text-[#23262E] text-center justify-self-end">HT</span>
        <span className="text-sm text-[#23262E] text-center justify-self-end">Corners</span>
      </div>

      <div className="flex gap-[10px]">
        <img src={list} alt="Menu" className="cursor-pointer " />
        <img src={arrow} alt="Expand" className="cursor-pointer " />
      </div>
      {/* <img src={arrow} alt="Expand" className="w-5 h-5 cursor-pointer block md:hidden" /> */}
    </div>

    <div className="md:hidden flex items-center justify-between w-full h-12 bg-[#23262E1A] px-4 py-2 gap-4"
     onClick={() => onToggleExpand()}>
      <div className="flex items-center gap-2 max-md">
        <img src={star} alt="Star" className="w-5 h-5 cursor-pointer" />
        <img src={flagSrc} alt="Flag" className="w-5 h-5" />
        <span className="text-[#23262E] text-sm font-medium">
          {country}: {league}
        </span>
        {/* <img src={pin} alt="Pin" className="w-5 h-5 cursor-pointer" /> */}
        <ReactSVG
        src={pin}
        className={"fill-[transparent] stroke-[black]"}
      />
      </div>
      <img src={arrow} alt="Expand" className="cursor-pointer " />

    </div>
    </>
  );
};

export default MatchHeader;