import React, { useState } from "react";
import MatchHeader from "./MatchHeader";
import MatchBody from "./MatchBody";

// Importing icons
import starIcon from "../../../assets/icons/Star.svg";
// import pinIcon from "../../../assets/icons/Pin.svg";
import listIcon from "../../../assets/icons/List.svg";
import arrowUpIcon from "../../../assets/icons/Up.svg"; // When expanded
import arrowDownIcon from "../../../assets/icons/Down.svg"; // When collapsed
import flagIcon from "../../../assets/icons/Arg.svg";
import homeLogo from "../../../assets/icons/homeTeam.svg";
import awayLogo from "../../../assets/icons/awayTeam.svg";
import tv from "../../../assets/icons/tvIcon.svg";
import jersey from "../../../assets/icons/jerseyIcon.svg";
import info from "../../../assets/icons/infoIcon.svg";
import pinIcon from "../../../assets/icons/Pin.svg";

// Match Data
const matchData = [
  {
    id: 1,
    country: "Argentina",
    league: "Liga Profesional",
    flagSrc: flagIcon,
    matches: [
      {
        matchtId: 1,
        time: "22:00",
        homeTeam: "Argentino Jrs",
        awayTeam: "Sarmiento Junin",
        homeTeamLogo: homeLogo,
        awayTeamLogo: awayLogo,
        homeScore: "-",
        awayScore: "-",
        htHomeScore: "-",
        htAwayScore: "-",
        cornersHome: "-",
        cornersAway: "-",
        redCardHome: 0,
        redCardAway: 0,
      },
    ],
  },
  {
    id: 2,
    country: "Argentina",
    league: "Reserve League - Second stage",
    flagSrc: flagIcon,
    matches: [
      {
        matchId: 1,
        time: "17:00",
        homeTeam: "Instituto 2",
        awayTeam: "Belgrano 2",
        homeTeamLogo: homeLogo,
        awayTeamLogo: awayLogo,
        homeScore: 0,
        awayScore: 2,
        htHomeScore: 0,
        htAwayScore: 2,
        cornersHome: 7,
        cornersAway: 2,
        redCardHome: 1,
        redCardAway: 0,
      },
    ],
  },
  {
    id: 3,
    country: "Bolivia",
    league: "Division Profesional - Clausura",
    flagSrc: flagIcon,
    matches: [
      {
        matchId: 1,
        time: "Finished",
        homeTeam: "Oriente Petrolero",
        awayTeam: "Royal Pari",
        homeTeamLogo: homeLogo,
        awayTeamLogo: awayLogo,
        homeScore: 0,
        awayScore: 0,
        htHomeScore: 0,
        htAwayScore: 0,
        cornersHome: 3,
        cornersAway: 4,
        redCardHome: 0,
        redCardAway: 0,
      },
      {
        matchtId: 2,
        time: "Finished",
        homeTeam: "Tomayapo",
        awayTeam: "Independiente",
        homeTeamLogo: homeLogo,
        awayTeamLogo: awayLogo,
        homeScore: 0,
        awayScore: 0,
        htHomeScore: 0,
        htAwayScore: 0,
        cornersHome: 0,
        cornersAway: 0,
        redCardHome: 0,
        redCardAway: 0,
      },
      {
        matchtId: 3,
        time: "23:00",
        homeTeam: "Santa Cruz",
        awayTeam: "The Strongest",
        homeTeamLogo: homeLogo,
        awayTeamLogo: awayLogo,
        homeScore: "-",
        awayScore: "-",
        htHomeScore: "-",
        htAwayScore: "-",
        cornersHome: "-",
        cornersAway: "-",
        redCardHome: 0,
        redCardAway: 0,
      },
    ],
  },
];

const MatchContainer: React.FC = () => {
  const [expandedLeagues, setExpandedLeagues] = useState<number[]>([1,2,3]);

  const toggleExpand = (id: number) => {
    setExpandedLeagues((prev) =>
      prev.includes(id)
        ? prev.filter((leagueId) => leagueId !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="flex flex-col w-full  mx-auto">
      {matchData.map((league, index) => {
        const isExpanded = expandedLeagues.includes(league.id);

        return (
          <div key={index} className="bg-white shadow">
            <MatchHeader
              flagSrc={league.flagSrc}
              country={league.country}
              league={league.league}
              star={starIcon}
              pin={pinIcon}
              list={listIcon}
              arrow={isExpanded ? arrowUpIcon : arrowDownIcon}
              id={league.id}
              onToggleExpand={() => toggleExpand(league.id)}
              isExpanded={isExpanded}
            />

            {isExpanded &&
              league.matches.map((match, matchIndex) => (
                <MatchBody
                  key={matchIndex}
                  starIcon={starIcon}
                  time={match.time}
                  homeTeam={match.homeTeam}
                  awayTeam={match.awayTeam}
                  homeTeamLogo={match.homeTeamLogo}
                  awayTeamLogo={match.awayTeamLogo}
                  htHomeScore={match.homeScore}
                  htAwayScore={match.awayScore}
                  homeScore={match.htHomeScore}
                  awayScore={match.htAwayScore}
                  cornersHome={match.cornersHome}
                  cornersAway={match.cornersAway}
                  redCardHome={match.redCardHome}
                  redCardAway={match.redCardAway}
                  tvIcon={tv}
                  jerseyIcon={jersey}
                  infoIcon={info}
                />
              ))}
          </div>
        );
      })}
    </div>
  );
};

export default MatchContainer;
