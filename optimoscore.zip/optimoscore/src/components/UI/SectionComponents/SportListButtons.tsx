import React, { useState } from "react";
import SportsItemButton from "./SportsItemButton";

interface SportItem {
  iconImg: string;
  text: string;
}

interface SportListButtonsProps {
  items: SportItem[];
  defaultActive?: string;
  onSportChange?: (sport: string) => void;
}

const SportListButtons: React.FC<SportListButtonsProps> = ({
  items,
  defaultActive = "",
  onSportChange,
}) => {
  const [activeSport, setActiveSport] = useState<string>(
    defaultActive || (items.length > 0 ? items[0].text : "")
  );

  const handleSportClick = (sport: string) => {
    setActiveSport(sport);
    if (onSportChange) {
      onSportChange(sport);
    }
  };

  return (
    <div className="mb-4 flex justify-between md:hidden overflow-x-scroll scrollbar-hide gap-0" style={{ scrollbarWidth: "none" }}>
      {items.map((item) => (
        <SportsItemButton
          key={item.text}
          iconImg={item.iconImg}
          text={item.text}
          isActive={activeSport === item.text}
          onClick={() => handleSportClick(item.text)}
        />
      ))}
    </div>
  );
};

export default SportListButtons;
