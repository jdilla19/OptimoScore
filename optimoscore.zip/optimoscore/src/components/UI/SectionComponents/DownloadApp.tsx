import { useState,FC } from "react";
import QR from "../../../assets/qr.png";
import apple from "../../../assets/icons/Apple.svg";
import google from "../../../assets/icons/Google Play.svg";
import uprow from "../../../assets/icons/Up.svg";



const DownloadApp: FC = () => {
  const [isOpen,setIsOpen] = useState<boolean>(true);
  return (
    <div className="flex-col items-center p-4 bg-white shadow-md rounded-2xl w-[302px] mt-[24px] transition-all duration-300 hidden  xl:flex ">
      <div 
        className="flex items-center justify-between w-full cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h2 className="text-[14px] font-semibold">Download Application</h2>
        <img 
          src={uprow} 
          alt="Toggle" 
          className={`transition-transform duration-300 ${isOpen ? "rotate-0" : "rotate-180"}`} 
        />
      </div>
      <div
        className={`flex flex-col items-center overflow-hidden transition-all duration-300 ${
          isOpen ? "max-h-[300px] opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <div className="w-[266px] h-[160px] bg-gray-200 flex items-center justify-center rounded-lg my-3">
          <img src={QR} alt="QR Code" className="rounded-lg" />
        </div>
        <span className="text-gray-500 text-sm my-2">OR</span>
        <div>
          <button className="w-[266px] h-[40px] flex items-center justify-center bg-gray-100 rounded-lg mb-2">
            <img src={google} alt="Google Play" className="h-5 mr-2" />
            Google Play
          </button>
          <button className="w-[266px] h-[40px] flex items-center justify-center bg-gray-100 rounded-lg">
            <img src={apple} alt="Apple Store" className="h-5 mr-2" />
            Apple Store
          </button>
        </div>
      </div>
    </div>
  );
};

export default DownloadApp;
