import React from "react";

type SportsItemProps = {
  iconImg: string;
  text: string;
  isActive?: boolean;
  onClick?: () => void;
};

const SportsItemButton: React.FC<SportsItemProps> = ({
  iconImg,
  text,
  isActive = false,
  onClick,
}) => {
  return (
    <div className="items-center justify-between  block lg:hidden">
      <button
        onClick={onClick}
        className={`flex flex-col items-center justify-center px-2 py-2 transition-colors relative`}
      >
        <img src={iconImg} alt={text} className="object-contain" />
        <span
          className={`text-[10px] ${
            isActive ? "font-medium text-black" : "text-[#23262EB2]"
          }`}
        >
          {text}
        </span>
        {isActive && (
          <div className="absolute bottom-0 left-0 w-full h-1 bg-black"></div>
        )}
      </button>
    </div>
  );
};

export default SportsItemButton;
