import Add from '../../../assets/Add.png'

const AddBanner = () => {
  return (
    <div className='mt-[24px] flex justify-center max-md:p-4 mx-auto w-full max-w-[682px]'>
        <img src={Add} alt="Add banner w-full " />
    </div>
  )
}

export default AddBanner