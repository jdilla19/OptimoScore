interface MatchBodyProps {
  starIcon: string;
  time: string;
  homeTeamLogo: string;
  homeTeam: string;
  awayTeamLogo: string;
  awayTeam: string;
  tvIcon: string;
  jerseyIcon: string;
  infoIcon: string;
  homeScore?: number | string;
  awayScore?: number | string;
  htHomeScore?: number | string;
  htAwayScore?: number | string;
  cornersHome?: number | string;
  cornersAway?: number | string;
  redCardHome?: number;
  redCardAway?: number;
}

const MatchBody: React.FC<MatchBodyProps> = ({
  starIcon,
  time,
  homeTeamLogo,
  homeTeam,
  awayTeamLogo,
  awayTeam,
  tvIcon,
  jerseyIcon,
  infoIcon,
  homeScore = "-",
  awayScore = "-",
  htHomeScore = "-",
  htAwayScore = "-",
  cornersHome = "-",
  cornersAway = "-",
  redCardHome = 0,
  redCardAway = 0,
}) => {
  return (
    <>
    <div className="grid grid-cols-[auto_1fr_auto_auto] justify-end  items-center w-full bg-white px-4 py-3 gap-4 max-md:hidden">
      <div className="flex items-center gap-3">
        <img src={starIcon} alt="Star" className="w-5 h-5 cursor-pointer" />
        <span className="text-gray-600 text-sm w-14 max-md:hidden">{time}</span>
      </div>

      <div className="grid gap-2">
        <div className="flex items-center gap-2">
          <img src={homeTeamLogo} alt={homeTeam} className="w-6 h-6" />
          <span className="text-gray-600 text-sm whitespace-nowrap">{homeTeam}</span>
          {redCardHome > 0 && (
            <span className="text-red-500 text-xs"></span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <img src={awayTeamLogo} alt={awayTeam} className="w-6 h-6" />
          <span className="text-gray-600 text-sm whitespace-nowrap">{awayTeam}</span>
          {redCardAway > 0 && (
            <span className="text-red-500 text-xs"></span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-4 gap-10 text-gray-700 text-sm">
        <div className="grid gap-1 text-center max-md:hidden">
          <span>{homeScore}</span>
          <span>{awayScore}</span>
        </div>
        <div className="grid gap-1 text-center max-md:hidden ">
          <span>{htHomeScore}</span>
          <span>{htAwayScore}</span>
        </div>
        <div className="grid gap-1 text-center max-md:hidden">
          <span>{cornersHome}</span>
          <span>{cornersAway}</span>
        </div>
      </div>

      <div className="flex gap-3 max-md:hidden">
        <img src={tvIcon} alt="TV" className="w-5 h-5 cursor-pointer" />
        <img src={jerseyIcon} alt="Jersey" className="w-5 h-5 cursor-pointer" />
        <img src={infoIcon} alt="Info" className="w-5 h-5 cursor-pointer" />
      </div>
      
      {/* <div className="grid grid-cols-2 gap-1 text-center justify-end items-center md:hidden ">
        <div className="flex flex-col">
        <span>{htHomeScore}</span>
        <span>{htAwayScore}</span>
        </div>
    
      <span className="text-gray-600 text-sm w-14">{time}</span>
      </div> */}
   
    </div>

    <div className="flex items-center justify-between px-4 py-2 h-[72px] md:hidden">
      {/* Left Section: Star icon, Team names & Logos */}
      <div className="flex items-center gap-2">
        <img src={starIcon} alt="Favorite" width={20} height={20} />
        <div className="flex flex-col gap-2 ml-[12px]">
        <div className="flex gap-2 ">
        <img src={homeTeamLogo} alt={homeTeam}  />
        <span className="text-sm ">{homeTeam}</span>
        </div>
        <div className="flex gap-2">
        <img src={awayTeamLogo} alt={awayTeam} />
        <span className="text-sm">{awayTeam}</span>
        </div>
        </div>
        
        
        
      </div>
      
      {/* Right Section: Scores & Time */}
      <div className="flex items-center justify-between gap-2 mr-[10px] min-w-[100px] ">
        <div className="flex flex-col  justify-between items-center ">
        <span className="text-sm">{htHomeScore ?? '-'}</span>
        <span className="text-sm">{htAwayScore ?? '-'}</span>
        </div>
        
        <span className="text-sm flex">{time}</span>
      </div>
    </div>
    </>
  );
};

export default MatchBody;