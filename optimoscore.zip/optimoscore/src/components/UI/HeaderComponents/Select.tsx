import { useState } from "react";
import { Dropdown} from "antd";
import Down from "../../../assets/icons/Down.svg";
import football from "../../../assets/icons/Football2.svg";
import basketball from "../../../assets/icons/Basketball.svg";
import hockey from "../../../assets/icons/Hockey.svg";
import rugby from "../../../assets/icons/Rugby.svg"
import handball from "../../../assets/icons/Handball.svg";

interface SportItem {
  icon: string;
  label: string;
  key:string;
}

const Select = () => {
  // Sports data array
  const sportsItems:SportItem[] = [
    {
      key: 'football',
      label: 'Football',
      icon: football
    },
    {
      key: 'basketball',
      label: 'Basketball',
      icon: basketball
    },
    {
      key: 'rugby',
      label: 'Rugby',
      icon: rugby
    },
    {
      key: 'hockey',
      label: 'Hockey',
      icon: hockey
    },

    {
      key: 'handball',
      label: 'Handball',
      icon: handball
    }
  ];

  // State for selected sport
  const [selectedSport, setSelectedSport] = useState(sportsItems[0]);

  // Handle sport selection
  const handleSportSelect = (key: string) => {
    const sport = sportsItems.find(item => item.key === key);
    if (sport) {
      setSelectedSport(sport);
    }
  };

  // Dropdown items
  const items = sportsItems.map(item => ({
    key: item.key,
    label: (
      <div 
        className="flex items-center gap-2 py-2 px-1"
        onClick={() => handleSportSelect(item.key)}
      >
        <div className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded-md">
          <img src={item.icon} alt={item.label} />
        </div>
        <span>{item.label}</span>
      </div>
    )
  }));



  return (
    <Dropdown
      menu={{ items }}
      placement="bottomLeft"
      trigger={['click']}
    >
      <button className="items-center w-[160px] h-[40px] bg-white border border-gray-200 rounded-[8px] shadow-sm hover:bg-gray-100 gap-[12px] hidden lg:flex">
        <div className="w-[40px] h-[40px] flex items-center justify-center bg-gray-100 rounded-[8px]">
          <img src={selectedSport.icon} alt={selectedSport.label} />
        </div>
        {/* Text and Dropdown */}
        <span className="flex-1 text-gray-900 text-xs">{selectedSport.label}</span>
        <span className="w-4 h-4 text-gray-500 mr-2">
          <img src={Down} alt="" />
        </span>
      </button>
    </Dropdown>
  );
};

export default Select;
