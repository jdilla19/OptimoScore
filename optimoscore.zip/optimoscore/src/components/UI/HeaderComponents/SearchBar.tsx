import search from "../../../assets/icons/Search.svg"

const SearchBar = () => {
  return (
    <>
      <button className="lg:hidden w-10 h-10 flex items-center justify-center bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-[8px]">
        <img src={search} alt="Search" className="w-5 h-5" />
      </button>

      <div className="hidden lg:flex items-center w-[300px] pl-6 h-10 border border-gray-300 rounded-[8px] overflow-hidden bg-white">
        <input
          type="text"
          placeholder="Search Match, Team or Player"
          className="flex-1 bg-transparent rounded-md text-xs text-[#23262e66] outline-none"
        />
        <button className="w-10 h-10 flex items-center justify-center bg-gray-100 hover:bg-gray-200">
          <img src={search} alt="Search" className="w-5 h-5" />
        </button>
      </div>
    </>
  );
}

export default SearchBar;
