interface IProps {
  iconUrl: string;
  onClick?: () => void;
}

const ButtonUrl = ({ iconUrl, onClick }: IProps) => {
  return (
    <div className="relative">
      <button
        className="bg-gray-100 border border-gray-200 rounded-[8px] h-[40px] w-[40px] items-center justify-center flex hover:bg-gray-200 transition-colors"
        onClick={onClick}
      >
        <img src={iconUrl} alt="" />
      </button>
    </div>
  );
};

export default ButtonUrl;
