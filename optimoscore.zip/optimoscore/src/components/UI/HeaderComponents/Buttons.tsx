// interface ButtonProps {
//   bgColor:string;
//   text:string;
//   textColor:string;
// }

// const Buttons:React.FC<ButtonProps> = ({bgColor,text,textColor}) => {
//   return (
//     <button className={`px-[16px]   m-auto h-[40px]  items-center justify-center border font-semibold border-[#23262E1A] rounded-[8px]  text-sm ${bgColor} ${textColor} `}>
//       {text}
//     </button>
//   );
// };

// export default Buttons;

import React from "react";

interface ButtonProps {
  textColor?: string;
  text?: string;
  isActive?: boolean;
  onClick?: () => void;
  activeBgColor?: string;
}

const Buttons: React.FC<ButtonProps> = ({
  textColor,
  text,
  isActive,
  activeBgColor = "bg-purple-500 text-white",
  onClick,
}) => {
  return (
    <button
      className={`px-[12px]  h-[40px] flex items-center whitespace-nowrap justify-center border font-semibold border-[#23262E1A] rounded-[8px] text-xs ${textColor} 
       ${isActive && activeBgColor}`}
      onClick={onClick}
    >
      {text}
    </button>
  );
};

export default Buttons;
