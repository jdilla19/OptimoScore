import React, { useState } from "react";
import { Drawer } from "antd";
import type { DrawerProps } from "antd";
import ButtonUrl from "./ButtonUrl";
import Setting from "../../../assets/icons/Setting.svg";
import Platform from "../../../assets/icons/Platform.svg";
import flagIcon from "../../../assets/icons/Flag.svg";
import PinnedLeagues from "../../cards/PinnedLeagues";
import CountriesCards from "../../cards/CountriesCards";

// interface League {
//     id: number;
//     imgUrl: string;
//     championship: string;
//     country: string;
//   }

//   interface Country {
//     name: string;
//   }

const SettingRow: React.FC<{
  label: string;
  value: string;
  icon?: string;
  onClick?: () => void;
}> = ({ label, value, icon, onClick }) => (
  <div
    onClick={onClick}
    className="flex items-center justify-between py-3 cursor-pointer border-b border-gray-100"
  >
    <span className="text-sm">{label}</span>
    <div className="flex items-center gap-2">
      {icon && <img src={icon} alt={value} className="w-5 h-5" />}
      <span className="text-sm text-gray-600">{value}</span>
      <svg
        className="w-4 h-4 text-gray-400"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M9 5l7 7-7 7"
        />
      </svg>
    </div>
  </div>
);

const BurgerMenu: React.FC = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [placement] = useState<DrawerProps["placement"]>("left");

  const showMenu = () => setMenuOpen(true);
  const closeMenu = () => setMenuOpen(false);
  const showSettings = () => {
    setSettingsOpen(true);
    setMenuOpen(false);
  };
  const closeSettings = () => setSettingsOpen(false);

  return (
    <div className="lg:hidden">
      <button
        onClick={showMenu}
        className="p-2 text-gray-600 hover:text-gray-800 focus:outline-none"
      >
        <div className="w-6 h-px bg-current mb-1"></div>
        <div className="w-6 h-px bg-current mb-1"></div>
        <div className="w-6 h-px bg-current"></div>
      </button>

      {/* Main Menu Drawer */}
      <Drawer
        title={
          <div className="flex justify-between items-center pr-4">
            <span>Menu</span>
            <div className="flex gap-2">
              <div onClick={showSettings} className="cursor-pointer">
                <ButtonUrl iconUrl={Setting} />
              </div>
              <ButtonUrl iconUrl={Platform} />
            </div>
          </div>
        }
        placement={placement}
        closable={true}
        onClose={closeMenu}
        open={menuOpen}
        width={280}
      >
        <div className="flex flex-col justify-start items-start">
          <div className="mb-6">
            <PinnedLeagues />

            <CountriesCards />
          </div>
        </div>
      </Drawer>

      {/* Settings Drawer */}
      <Drawer
        title={
          <div className="flex items-center gap-2">
            <ButtonUrl iconUrl={Setting} />
            <span>Settings</span>
          </div>
        }
        placement={placement}
        closable={true}
        onClose={closeSettings}
        open={settingsOpen}
        width={280}
      >
        <div className="flex flex-col">
          <SettingRow label="Language" value="English" icon={flagIcon} />
          <SettingRow label="Timezone" value="GMT +4" />
          <SettingRow label="Odds" value="EU (1.50)" />
          <SettingRow label="Theme" value="Light"  />
        </div>
      </Drawer>
    </div>
  );
};

export default BurgerMenu;
