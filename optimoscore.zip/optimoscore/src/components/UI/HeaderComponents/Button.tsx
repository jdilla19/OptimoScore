interface IProps {
  iconUrl: string;
  text:string;
  count:number;
}

const Button = ({ iconUrl,text,count}: IProps) => {
  return (
    <>
      <button className="items-center  justify-between w-[175px] h-[40px] bg-white border border-gray-200 rounded-[8px] shadow-sm hover:bg-gray-100 gap-[6px] px-[16px] hidden lg:flex">
        <img src={iconUrl} alt="" />
        <span className="text-gray-900 text-xs"> {text}</span>
        <div className="w-[34px] h-[24px] flex items-center justify-center bg-gray-100 rounded-[100px]">
          {count}
        </div>
      </button>
    </>
  );
};

export default Button;
