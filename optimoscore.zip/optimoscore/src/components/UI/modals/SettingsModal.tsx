import React from "react";
import { DownOutlined } from "@ant-design/icons";
import { Modal } from "antd";

interface SettingsModalProps {
  isOpen: boolean;
  handleClose?: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({
  handleClose,
  isOpen,
}) => {
  return (
    <Modal
      closable={false}
      footer={false}
      centered={true}
      open={isOpen}
      onCancel={handleClose}
      width={490}
      className=""
    >
      <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-200">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-base font-medium">Settings</h3>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <span className="text-xl font-light">×</span>
          </button>
        </div>

        <div className="space-y-6">
          {/* Language Setting */}
          <div className="flex justify-between items-center">
            <span className="text-gray-700">Language</span>
            <div className="relative">
              <select
                className="appearance-none bg-white border border-gray-200 rounded-md py-2 pl-3 pr-10 text-sm leading-5 focus:outline-none focus:ring-1 focus:ring-blue-500"
                defaultValue="english"
              >
                <option value="english">🇬🇧 English</option>
                <option value="french">🇫🇷 French</option>
                <option value="german">🇩🇪 German</option>
                <option value="spanish">🇪🇸 Spanish</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                <DownOutlined className="h-4 w-4" />
              </div>
            </div>
          </div>

          {/* Timezone Setting */}
          <div className="flex justify-between items-center">
            <span className="text-gray-700">Timezone</span>
            <div className="relative">
              <select
                className="appearance-none bg-white border border-gray-200 rounded-md py-2 pl-3 pr-10 text-sm leading-5 focus:outline-none focus:ring-1 focus:ring-blue-500"
                defaultValue="gmt4"
              >
                <option value="gmt4">GMT +4</option>
                <option value="gmt5">GMT +5</option>
                <option value="gmt0">GMT +0</option>
                <option value="gmtm5">GMT -5</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                <DownOutlined className="h-4 w-4" />
              </div>
            </div>
          </div>

          {/* Odds Setting */}
          <div className="flex justify-between items-center">
            <span className="text-gray-700">Odds</span>
            <div className="relative">
              <select
                className="appearance-none bg-white border border-gray-200 rounded-md py-2 pl-3 pr-10 text-sm leading-5 focus:outline-none focus:ring-1 focus:ring-blue-500"
                defaultValue="eu"
              >
                <option value="eu">EU (1.50)</option>
                <option value="uk">UK (1/2)</option>
                <option value="us">US (-200)</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                <DownOutlined className="h-4 w-4" />
              </div>
            </div>
          </div>

          {/* Theme Setting */}
          <div className="flex justify-between items-center">
            <span className="text-gray-700">Theme</span>
            <div className="relative">
              <select
                className="appearance-none bg-white border border-gray-200 rounded-md py-2 pl-3 pr-10 text-sm leading-5 focus:outline-none focus:ring-1 focus:ring-blue-500"
                defaultValue="light"
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                <DownOutlined className="h-4 w-4" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default SettingsModal
;
