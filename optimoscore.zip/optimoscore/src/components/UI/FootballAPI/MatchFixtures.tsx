// src/components/MatchFixtures.tsx
import React, { useEffect, useState } from 'react';
import { getCompetitionMatches, MatchesResponse, Match } from "../FootballAPI/footballDataApi";

interface MatchFixturesProps {
  competitionCode: string;
  title?: string;
  limit?: number;
}

const MatchFixtures: React.FC<MatchFixturesProps> = ({ 
  competitionCode, 
  title,
  limit = 10
}) => {
  const [matches, setMatches] = useState<Match[]>([]);
  const [competition, setCompetition] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchMatches = async () => {
      try {
        setLoading(true);
        const data: MatchesResponse = await getCompetitionMatches(competitionCode);
        
        // Sort matches by date (most recent first)
        const sortedMatches = [...data.matches].sort((a, b) => 
          new Date(b.utcDate).getTime() - new Date(a.utcDate).getTime()
        );
        
        setMatches(sortedMatches.slice(0, limit));
        setCompetition(data.competition.name);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching matches:', err);
        setError('Failed to load matches. Please try again later.');
        setLoading(false);
      }
    };

    fetchMatches();
  }, [competitionCode, limit]);

  const formatMatchDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-GB', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getStatusStyles = (status: string) => {
    switch (status) {
      case 'FINISHED':
        return 'bg-green-100 text-green-800';
      case 'IN_PLAY':
      case 'PAUSED':
        return 'bg-yellow-100 text-yellow-800 animate-pulse';
      case 'SCHEDULED':
      case 'TIMED':
        return 'bg-blue-100 text-blue-800';
      case 'POSTPONED':
      case 'CANCELED':
      case 'SUSPENDED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="bg-gray-800 text-white px-6 py-4">
        <h2 className="text-xl font-bold">{title || competition} Matches</h2>
      </div>
      
      <div className="divide-y divide-gray-200">
        {matches.map((match) => (
          <div key={match.id} className="p-4 hover:bg-gray-50">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-500">{formatMatchDate(match.utcDate)}</span>
              <span className={`text-xs px-2 py-1 rounded-full ${getStatusStyles(match.status)}`}>
                {match.status.replace('_', ' ')}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center w-2/5 justify-end">
                <span className="font-medium text-right">{match.homeTeam.shortName || match.homeTeam.name}</span>
                {match.homeTeam.crest && (
                  <img 
                    src={match.homeTeam.crest} 
                    alt={`${match.homeTeam.name} crest`} 
                    className="h-6 w-6 ml-2"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                )}
              </div>
              
              <div className="mx-4 text-center">
                {match.status === 'FINISHED' || match.status === 'IN_PLAY' || match.status === 'PAUSED' ? (
                  <div className="flex items-center justify-center space-x-1">
                    <span className="font-bold text-lg">{match.score.fullTime.home}</span>
                    <span className="font-bold text-lg">-</span>
                    <span className="font-bold text-lg">{match.score.fullTime.away}</span>
                  </div>
                ) : (
                  <span className="text-xs font-semibold text-gray-500">VS</span>
                )}
              </div>
              
              <div className="flex items-center w-2/5">
                {match.awayTeam.crest && (
                  <img 
                    src={match.awayTeam.crest} 
                    alt={`${match.awayTeam.name} crest`} 
                    className="h-6 w-6 mr-2"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                )}
                <span className="font-medium">{match.awayTeam.shortName || match.awayTeam.name}</span>
              </div>
            </div>
          </div>
        ))}
        
        {matches.length === 0 && (
          <div className="p-6 text-center text-gray-500">
            No matches available at the moment.
          </div>
        )}
      </div>
    </div>
  );
};

export default MatchFixtures;