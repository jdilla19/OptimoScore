// src/components/FootballDashboard.tsx
import React, { useState, useEffect } from 'react';
import LeagueStandings from './LeagueStandings';
import MatchFixtures from './MatchFixtures';
import { getCompetitions, Competition } from "../FootballAPI/footballDataApi";

const FootballDashboard: React.FC = () => {
  const [selectedCompetition, setSelectedCompetition] = useState<string>('PL'); // Default to Premier League
  const [competitions, setCompetitions] = useState<Competition[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchCompetitions = async () => {
      try {
        setLoading(true);
        const response = await getCompetitions();
        // Filter to get only leagues (not cups)
        const leagues = response.competitions.filter(
          (comp: Competition) => comp.type === 'LEAGUE'
        );
        setCompetitions(leagues);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching competitions:', error);
        setLoading(false);
      }
    };

    fetchCompetitions();
  }, []);

  const handleCompetitionChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedCompetition(event.target.value);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Football Dashboard</h1>
      
      <div className="mb-6">
        <label htmlFor="competition-select" className="block text-sm font-medium text-gray-700 mb-2">
          Select Competition
        </label>
        <select
          id="competition-select"
          className="block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          value={selectedCompetition}
          onChange={handleCompetitionChange}
          disabled={loading}
        >
          {loading ? (
            <option>Loading competitions...</option>
          ) : (
            competitions.map((competition) => (
              <option key={competition.id} value={competition.code}>
                {competition.name}
              </option>
            ))
          )}
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <LeagueStandings competitionCode={selectedCompetition} />
        </div>
        <div>
          <MatchFixtures competitionCode={selectedCompetition} limit={10} />
        </div>
      </div>
    </div>
  );
};

export default FootballDashboard;