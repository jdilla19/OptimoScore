import axios from 'axios';

// Types for the Football Data API
export interface Team {
  id: number;
  name: string;
  shortName: string;
  tla: string;
  crest: string;
}

export interface Competition {
  id: number;
  name: string;
  code: string;
  type: string;
  emblem: string;
}

export interface Standing {
  position: number;
  team: Team;
  playedGames: number;
  won: number;
  draw: number;
  lost: number;
  points: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
}

export interface StandingsResponse {
  filters: Record<string, unknown>;
  competition: Competition;
  season: {
    id: number;
    startDate: string;
    endDate: string;
    currentMatchday: number;
  };
  standings: Array<{
    stage: string;
    type: string;
    group: string | null;
    table: Standing[];
  }>;
}

export interface Match {
  id: number;
  utcDate: string;
  status: string;
  matchday: number;
  stage: string;
  homeTeam: Team;
  awayTeam: Team;
  score: {
    fullTime: {
      home: number | null;
      away: number | null;
    };
    halfTime: {
      home: number | null;
      away: number | null;
    };
  };
}

export interface MatchesResponse {
  count: number;
  filters: Record<string, unknown>;
  competition: Competition;
  matches: Match[];
}

// Create the API client
const API_KEY = 'YOUR_API_KEY'; // Replace with your API key from football-data.org
const BASE_URL = 'https://api.football-data.org/v4';

const FootballDataApi = axios.create({
  baseURL: BASE_URL,
  headers: {
    'X-Auth-Token': API_KEY
  }
});

// API functions
export const getCompetitions = async () => {
  const response = await FootballDataApi.get('/competitions');
  return response.data;
};

export const getCompetitionStandings = async (competitionCode: string): Promise<StandingsResponse> => {
  const response = await FootballDataApi.get(`/competitions/${competitionCode}/standings`);
  return response.data;
};

export const getTeamMatches = async (teamId: number): Promise<MatchesResponse> => {
  const response = await FootballDataApi.get(`/teams/${teamId}/matches`);
  return response.data;
};

export const getCompetitionMatches = async (competitionCode: string): Promise<MatchesResponse> => {
  const response = await FootballDataApi.get(`/competitions/${competitionCode}/matches`);
  return response.data;
};

export default FootballDataApi;