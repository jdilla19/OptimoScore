// src/components/LeagueStandings.tsx
import React, { useEffect, useState } from 'react';
import { getCompetitionStandings, StandingsResponse, Standing } from "../FootballAPI/footballDataApi";

interface LeagueStandingsProps {
  competitionCode: string;
  title?: string;
}

const LeagueStandings: React.FC<LeagueStandingsProps> = ({ 
  competitionCode, 
  title 
}) => {
  const [standings, setStandings] = useState<Standing[]>([]);
  const [competition, setCompetition] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStandings = async () => {
      try {
        setLoading(true);
        const data: StandingsResponse = await getCompetitionStandings(competitionCode);
        
        // Most competitions have a TOTAL standings type
        const totalStandings = data.standings.find(s => s.type === 'TOTAL');
        
        if (totalStandings) {
          setStandings(totalStandings.table);
          setCompetition(data.competition.name);
        } else if (data.standings.length > 0) {
          // Fallback to first standings group if TOTAL is not available
          setStandings(data.standings[0].table);
          setCompetition(data.competition.name);
        }
        
        setLoading(false);
      } catch (err) {
        console.error('Error fetching standings:', err);
        setError('Failed to load standings. Please try again later.');
        setLoading(false);
      }
    };

    fetchStandings();
  }, [competitionCode]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="bg-gray-800 text-white px-6 py-4">
        <h2 className="text-xl font-bold">{title || competition} Standings</h2>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pos</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Team</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">MP</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">W</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">D</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">L</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">GF</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">GA</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">GD</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pts</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {standings.map((standing) => (
              <tr key={standing.team.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {standing.position}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    {standing.team.crest && (
                      <img 
                        src={standing.team.crest} 
                        alt={`${standing.team.name} crest`} 
                        className="h-6 w-6 mr-2"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                        }}
                      />
                    )}
                    <span className="text-sm font-medium text-gray-900">
                      {standing.team.shortName || standing.team.name}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{standing.playedGames}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{standing.won}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{standing.draw}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{standing.lost}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{standing.goalsFor}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{standing.goalsAgainst}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{standing.goalDifference}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{standing.points}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LeagueStandings;