import footerPic from "../assets/icons/Vector.svg";
import theSport from "../assets/icons/TheSports.svg";
import arrow from "../assets/icons/up.svg";
import { useState } from "react";

const optimoscoreSection = {
  title: "OPTIMOSCORE",
  links: ["Contact Us", "Advertise", "Terms of Use", "Privacy Policy"],
};

const footerSections = [
  {
    title: "FOOTBALL",
    links: [
      "Transfers News",
      "Live",
      "Premier League",
      "Seria A",
      "Ligue 1",
      "Bundesliga",
    ],
  },
  {
    title: "TENNIS",
    links: [
      "ATP Montreal 2024",
      "WTA Cincinnati 2024",
      "ATP US Open 2024",
      "WTP US Open 2024",
      "ATP Tour Calendar 2024",
    ],
  },
  {
    title: "BASKETBALL",
    links: [
      "NBA Players Comparison",
      "NBA Schedule",
      "NBA Standings",
      "NBA Teams",
      "CBA Schedule",
      "CBA Standings",
    ],
  },
  {
    title: "OTHER SPORTS",
    links: [
      "Formula 1",
      "MotoCP",
      "2024 Paris Olympic Games",
      "2024 Paris Overall Schedule",
      "PGA Tour 2024 Calendar",
      "Basketball Olympic Games 2024",
    ],
  },
];

const Footer = () => {
  const [openSections, setOpenSections] = useState<string[]>([]);

  const toggleSection = (title: string) => {
    setOpenSections((prev) =>
      prev.includes(title) ? prev.filter((t) => t !== title) : [...prev, title]
    );
  };

  return (
    <footer className="w-full bg-[white] mt-[120px]">
      
      {/* Desktop version */}

      <div className="con pt-[40px]  flex-col hidden md:flex">
        <div className="flex justify-between items-center mb-12 gap-[10px]">
          <div className="mb-8">
            <h3 className="text-[14px] font-semibold mb-4">
              {optimoscoreSection.title}
            </h3>
            <ul className="space-y-2">
              {optimoscoreSection.links.map((link) => (
                <li
                  key={link}
                  className="text-gray-600 hover:text-gray-900 cursor-pointer"
                >
                  {link}
                </li>
              ))}
            </ul>
          </div>
          <div className="flex max-w-[750px] w-full">
            <p className="text-[14px]  text-[#23262E] ">
              Football live scores page on Flashscore.com offers all the latest
              football results from EPL 2024 and more than 100+ football leagues
              and tournaments all around the world including the most famous:
              LaLiga, Serie A, Bundesliga, UEFA Champions League and also other
              leagues such as MLS or Saudi Pro League. Follow all the latest
              football results on Flashscore.com where you can find previews of
              football matches, detailed statistics (shots on goal, ball
              possession, expected goals (xG), corner stats, yellow and red
              cards, fouls etc.)
            </p>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-[8] mb-12">
          {footerSections.map((section, index) => (
            <div key={index}>
              <h3 className="font-bold text-[14px] mb-4">{section.title}</h3>
              <ul>
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex} className="mb-[2[]]">
                    <a href="#" className="text-gray-600 hover:text-gray-900">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="flex justify-between border-t pt-6 text-sm text-center space-y-2 bg-[white]">
          <div className="flex  ">
            <div className=" flex items-center gap-[3px]">
              <img src={footerPic} alt="" />
              <img
                src={theSport}
                alt=""
                className=" border-r pr-[5px] border-[#23262E1A]"
              />
              <div>OptimoScore’s Sports Data Provider</div>
            </div>
          </div>

          <div>Copyright © 2024 OptimoScore | iB - Gamble Responsibility</div>
        </div>
      </div>

      {/* Mobile version     */}

      <div className="con mx-auto px-4 block md:hidden">
        <div className="flex text-sm mt-[32px] mb-[32px]">
          <p>
            Football live scores page on Flashscore.com offers all the latest
            football results from EPL 2024 and more than 100+ football leagues
            and tournaments all around the world including the most famous:
            LaLiga, Serie A, Bundesliga, UEFA Champions League and also other
            leagues such as MLS or Saudi Pro League. Follow all the latest
            football results on Flashscore.com where you can find previews of
            football matches, detailed statistics (shots on goal, ball
            possession, expected goals (xG), corner stats, yellow and red cards,
            fouls etc.)
          </p>
        </div>

        {[optimoscoreSection, ...footerSections].map((section) => (
          <div key={section.title} className="mb-4 border-b border-gray-300">
            <button
              className="w-full text-left py-4 font-semibold flex justify-between items-center"
              onClick={() => toggleSection(section.title)}
            >
              {section.title}
              <img
                src={arrow}
                alt="Toggle Section"
                className={`w-4 h-4 transform transition-transform duration-300 ${
                  openSections.includes(section.title)
                    ? "rotate-180"
                    : "rotate-0"
                }`}
              />
            </button>
            {openSections.includes(section.title) && (
              <ul className="space-y-2 pb-4">
                {section.links.map((link) => (
                  <li
                    key={link}
                    className="text-gray-600 hover:text-gray-900 cursor-pointer"
                  >
                    {link}
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}

        <div className="flex flex-col gap-[16px]">
          <div className="flex">
            <img src={footerPic} alt="" />
            <img
              src={theSport}
              alt=""
              className=" border-r pr-[5px] border-[#23262E1A]"
            />
          </div>

          <div className="flex flex-col gap-[12px] text-[#23262EB2] text-xs">
            <p>OptimoScore’s Sports Data Provider</p>
            <p>Copyright @ 2024 OptimoScore</p>
            <p>18+ Gamble Responsibly</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
